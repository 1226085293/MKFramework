/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./panel/**/*.{ts,html,js}"],
  theme: {
    extend: {},
  },
  plugins: [],
}

