declare enum L10nListenEvent {
    languageChanged = "languageChanged",
    onMissingKey = "missingKey"
}
export default L10nListenEvent;
