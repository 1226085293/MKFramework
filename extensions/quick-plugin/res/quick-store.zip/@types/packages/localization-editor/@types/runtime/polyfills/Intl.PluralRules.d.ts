import 'intl-pluralrules';
