import fs from "fs";
import path from "path";
import config from "../config";
import { createApp, App } from "vue";
import { InspectorInfo, PanelInfo, Self } from "../types";
import electron, { BrowserWindow } from "electron";
import tool from "../tool";

// export const info: InspectorInfo = {
// 	type_s: "asset",
// 	target_s: "effect",
// };
export const info: PanelInfo = {
	title_s: "面板",
	width_n: 500,
	height_n: 500,
};

export let self: Self;

export let data = {
	counter: 0,
};

export let methods = {
	test() {
		data.counter++;
		// Editor.Dialog.info("测试按钮");
	},
};

export const panel = Editor.Panel.define({
	template: `<div id="app" class="w-full h-full"><panel></panel></div>`,
	get style() {
		return tool.get_panel_content(__filename).style_s;
	},
	$: {
		app: "#app",
	},
	methods: {},
	ready() {
		if (this.$.app) {
			const app = createApp({});
			app.config.compilerOptions.isCustomElement = (tag: string) =>
				tag.startsWith("ui-");
			app.component("panel", {
				template: tool.get_panel_content(__filename).html_s,
				data() {
					return data;
				},
				methods: methods,
				mounted() {
					self = this as any;
					data = (this as any).$data;
				},
			});
			app.mount(this.$.app);
		}

		// 非 inspector 面板 F5 刷新
		if (!(info as any).target_s) {
			let webFrame = electron.webFrame;
			let window = (webFrame as any).context as typeof globalThis;

			window.addEventListener("keydown", function (event) {
				if (event.key === "F5") {
					window.location.reload();
				}
			});
		}
	},
	// update(dump: any) {
	// 	self.dump = dump;
	// },
	beforeClose() {},
	close() {},
});
